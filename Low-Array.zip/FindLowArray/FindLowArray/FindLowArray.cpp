#include <iostream>
using namespace std;

int main()
{
    int num[5] = { 3,6,10,20,11 };
    int low;
    low = num[0];

    for (int i = 0; i < 5; i++) {
        if (num[i] < low) {
            low = num[i];
        }
    }

    cout << "Smallest element of an array is " << low;
}